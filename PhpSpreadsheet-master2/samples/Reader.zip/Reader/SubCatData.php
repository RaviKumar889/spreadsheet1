<?php
include('database.php');
if(isset($_POST['value'])) {
    $category = "select sub_category FROM users where category = '".$_POST['value']."' group by sub_category";
    $resultcategory = $conn->query($category);
    if ($resultcategory->num_rows > 0) {
        while($row_cat = $resultcategory->fetch_assoc()) {
            $resCat[] = $row_cat;
        }

        $categories = implode(',',$resCat);
        // echo('<pre>');
        // print_r($categories);

    echo json_encode($resCat);
    }
    
} else {
    echo('');
}
// $category = "select sub_category FROM users";
// $resultcategory = $conn->query($category);
// if ($resultcategory->num_rows > 0) {    
//     while($row_cat = $resultcategory->fetch_assoc()) { 
//         $resCat[] = $row_cat;
                     
//     }
//     echo json_encode($resCat);  
// } 
?>
